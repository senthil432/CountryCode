package com.example.countrylistapp.restapi

class ApiConstantsUrl {

    companion object {

        const val BASE_URL = "http://tailorschoice.in"

        const val COUNTRY_LIST = "/TssAppServices/http/CallServiceGet?data={\"method\":0,\"pwd\":\"test\",\"uname\":\"test\"}"

    }

}